<?php

$host = "sql202.infinityfree.com";
$username = "if0_42771166";
$password = "YOUR_INFINITYFREE_PASSWORD";
$database = "if0_42771166_park";

$con = mysqli_connect(
    $host,
    $username,
    $password,
    $database
);

if (!$con) {
    die("Database Connection Failed: " . mysqli_connect_error());
}

mysqli_set_charset($con, "utf8mb4");

?>